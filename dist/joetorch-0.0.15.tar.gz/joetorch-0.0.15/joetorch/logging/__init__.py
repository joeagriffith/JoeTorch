from joetorch.logging.tensorboard import get_writer

__all__ = ['get_writer']
