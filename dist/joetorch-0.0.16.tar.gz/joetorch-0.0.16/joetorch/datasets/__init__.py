from joetorch.datasets.mnist import MNIST, FashionMNIST
from joetorch.datasets.dataset import PreloadedDataset

__all__ = ['MNIST', 'FashionMNIST', 'PreloadedDataset']